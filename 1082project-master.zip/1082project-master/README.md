# name:Block, Shoot, Reload
 
# Description

This program is a school project and will be a game. The game is similar to a rock-paper-scissor game but instead will have a shoot-defend-reload systeme and some set of rules to be followed. The rules will be as followed:

-You can have a max of 3 ammo.

-You cannot block more than 3 times in a row. 

-You can only shoot if you have ammo.

-Each player will have 3 lives and will go until someone reaches 0.

In the beginning of the round, a player can either choose to reload, shoot, or block. 
Reloading will fill your "gun".  Shooting will cause the other player to lose a life unless that person is blocking. If a player chooses to shoot, they lose -1 ammo. Blocking will shield the player from shots

# Project features

-Uses a GUI

-Has Menu. start game, fight, and new game

-display images for chosen fight action

-record player data into a saved file

-Has a sorted learderboard

# Project requiments

1.Must use the OOP principles

2.Must use at least two packages

3.Must include at least Sixclasses

4.Must use Graphical User Interface (GUI)

5.Must use GitHub

# Project completition step-by-step

Step 1: 

-forming a group to work on the project.

Step 2:

-choose a project idea. 

Step 3

-created a github repository 

-created a flowchart of the game

Step 4:

-coded the main feature of the game

-Step 5:

-designing a GUI

-step 6:

-completed project

-step 7:

-Presentation

# Credits

Tristan Vu

Austin Thor
