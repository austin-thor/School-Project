package edu.game.Component;

public class Human extends Player {
	
	private String name;
	
	//setter getter - methods
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
